package testpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;

public class AutomationClass {

    public static WebDriver driver;
    public static Properties prob;

    public void browserInvocation() throws IOException  // This method is used to invoke the browser
    {
        driver = new ChromeDriver();
        ChromeOptions c = new ChromeOptions();
        c.setAcceptInsecureCerts(true);
        c.addArguments("--disable-notifications");
        FileInputStream fis = new FileInputStream(new File("src/main/resources/configuration/config.properties"));
        prob = new Properties();
        prob.load(fis);
        driver.navigate().to(prob.getProperty("url"));
        driver.manage().window().maximize();
        driver.findElement(By.xpath("//input[@placeholder='Search for products, brands and more']")).click();
    }

    public void search() {
        driver.findElement(By.xpath("//input[@class='desktop-searchBar']")).sendKeys(prob.getProperty("search") + Keys.ENTER);

    }

    public void select() {
        driver.findElement(By.xpath("//div[@class='search-searchProductsContainer row-base']//li[9]//h4[@class='product-product']")).click();
        ArrayList<String> list = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(list.get(1));

    }

    public void addtocart() {

        //driver.findElement(By.xpath("//div[text()='ADD TO BAG']")).click();
        driver.findElement(By.xpath("//div[text()='ADD TO BAG']")).click();

    }

    public void gotobag() {
        //driver.findElement(By.cssSelector("pdp-goToCart pdp-add-to-bag pdp-button pdp-flex pdp-center ")).click();
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(60));
        w.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@class='pdp-goToCart pdp-add-to-bag pdp-button pdp-flex pdp-center ']")));
        driver.findElement(By.xpath("//a[@class='pdp-goToCart pdp-add-to-bag pdp-button pdp-flex pdp-center ']")).click();

    }

    public void close() {
        driver.quit();
    }
}
