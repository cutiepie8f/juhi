package testpackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static testpackage.AutomationClass.driver;

public class TestClass {

    AutomationClass a = new AutomationClass();

    @Before
    public void setup() throws IOException {
        a.browserInvocation();
    }

    @Test
    public void MyntraPage () {
         a.search();
         a.select();
         a.addtocart();
         a.gotobag();

    }

    @After
   public void teardown() {
        a.close();
   }
}
