package testpackage;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;

public class AutomationClass {

    public  static WebDriver driver;
    public  static Properties prob;
    public void browserInvocation() throws IOException  // This method is used to invoke the browser
    {
        driver = new ChromeDriver();
        FileInputStream fis = new FileInputStream(new File("src/main/resources/configuration/config.properties"));
        prob = new Properties();
        prob.load(fis);
        driver.navigate().to(prob.getProperty("url"));
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.findElement(By.xpath("//span[@class='commonModal__close']")).click();
    }

    public void selectDepartureCity(String city)
    {
        driver.findElement(By.xpath("//input[@id='fromCity']")).click();
        driver.findElement(By.xpath("//p[text()='" + city + "']")).click();
    }

    public boolean validateDepartureCity() // This method is used to validate whether the departure city is selected or not
    {
        boolean res = driver.findElement(By.xpath("//input[@value='Mumbai']")).isDisplayed();
        return res;
    }
    public void selectArrivalCity(String city)
    {
        driver.findElement(By.xpath("//input[@id='toCity']")).click();
        driver.findElement(By.xpath("//p[text()='" + city + "']")).click();
    }
    public boolean validateArrivalCity() // This method is used to validate whether the departure city is selected or not
    {
        boolean res = driver.findElement(By.xpath("//input[@value='Bengaluru']")).isDisplayed();
        return res;
    }

    public  boolean calenderIsEnabled() // This method is used to validate whther the calender is enabled or not
    {
        boolean result =  driver.findElement(By.xpath("//div[@class='datePickerContainer']")).isEnabled();
        return result;
    }

    public void dateDropdown(String date) // This method is used to select the date from the dropdown list
    {

        while(!driver.findElement(By.xpath("//div[@class='DayPicker-Caption'][1]")).getText().equals("February 2024"))
        {
            driver.findElement(By.xpath("//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")).click();
        }
        WebElement element = driver.findElement(By.xpath("//div[@class='DayPicker-Body']"));
        element.findElement(By.xpath("//p[text()='"+date+"']")).click();
    }

    public boolean validateDateDropdown() // This method is used to validate whether the date is selected or not
    {
        boolean res = driver.findElement(By.xpath("//p[@class='blackText font20 code lineHeight36']//span[text()='20']")).isDisplayed();
        return res;
    }

    public void selectTravellers(String travellers)
    {
        driver.findElement(By.xpath("//label[@for='travellers']")).click();
        driver.findElement(By.xpath("//li[@data-cy='adults-"+travellers+"']")).click();
        driver.findElement(By.xpath("//button[@type='button']")).click();
    }

    public boolean validateTravellers() // This method is used to validate whether the number of passengers is selected or not
    {
        boolean res = driver.findElement(By.xpath("//p[@class='blackText font20 code lineHeight36']//span[text()='4']")).isDisplayed();
        return res;
    }

    public void selectFareType()
    {
        driver.findElement(By.xpath("//li[@class='font12 blackText wrapFilter  '][2]")).click();
    }
    public  boolean validateFareType() // This method is used to validate the radio button Whether it is selected or not
    {
        boolean result =  driver.findElement(By.xpath("//ul[@class='specialFareNew']//p[text()='Student ']")).isSelected();
        System.out.println(result);
        return result;

    }
    public void clickOnSearchButton()
    {
        driver.findElement(By.cssSelector(".primaryBtn.font24.latoBold.widgetSearchBtn ")).click();

        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(80));
        w.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//span[text()='Flights from ']")));

        driver.findElement(By.cssSelector(".bgProperties.overlayCrossIcon.icon20")).click();
    }
    public String validateFlightSelectingPage() {
        String actualText = driver.findElement(By.xpath("//span[text()='Flights from ']")).getText();
        return actualText;
    }

    public void selectFlight() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,250)", "");
        driver.findElement(By.xpath("//div[@class='']//span[text()='View Prices']")).click();
        driver.findElement(By.xpath("//button[text()='Book Now']")).click();
    }

    public String validateFlighytBookingPage()
    {
        ArrayList<String> list = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(list.get(1));

        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(80));
        w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='flightBody']")));

        String actualText = driver.findElement(By.xpath("//h2[@class='fontSize20 blackFont whiteText headerTitle']")).getText();
       return actualText;
    }
    public void selectInformationCheckbox()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,300)", "");
        driver.findElement(By.xpath("//div[@id='rtaImpinfo-consent']//input[@type='checkbox']")).click();
    }
    public boolean validateInformationCheckboxIsSelected()
    {
        boolean res = driver.findElement(By.xpath("//div[@id='rtaImpinfo-consent']//input[@value='true']")).isSelected();
        return res;
    }

    public void selectTripSecureRadioButton()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,380)", "");
        driver.findElement(By.xpath("//div[@class='insBottomSectionV3_2']//div[1]//span")).click();
    }
    public boolean validateTripSecureRadioButton()
    {
        boolean res = driver.findElement(By.xpath("//div[@class='secureTripsWrapper appendBottom20']//div//p//span")).isDisplayed();
        return res;
    }
    public void addTravellersDetails() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,420)", "");
        for (int i = 1; i <=Integer.parseInt(prob.getProperty("adultTravellers")); i++) {

            driver.findElement(By.xpath("//button[@class='addTravellerBtn']")).click();
            //driver.findElement(By.xpath("//div[@class='adultDetailsForm']//input")).sendKeys(prob.getProperty("travellersFirstName"));
            driver.findElement(By.xpath("//div[@class='adultDetailsForm']//input[@value='']")).sendKeys(prob.getProperty("traveller"+i+"_FirstName"));
            //driver.findElement(By.xpath("//div[@class='adultDetailsForm']//div[@class='adultItem'][2]//input")).sendKeys(prob.getProperty("travellersLatName"));
            driver.findElement(By.xpath("//div[@class='adultDetailsForm']//input[@value='']")).sendKeys(prob.getProperty("traveller"+i+"_LatName"));

            //driver.findElement(By.xpath("//div[@class='adultDetailsForm']//div[@class='adultItem'][3]//label[@tabindex='1']")).click();
            driver.findElement(By.xpath("//div[@class='adultDetailsForm']//div[@class='adultItem'][3]//div[@class='selectTab ']//label[@tabindex='1']//input[@value]")).click();
        }

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,420)", "");
        driver.findElement(By.xpath("//div[@id='Mobile No']//input")).sendKeys(prob.getProperty("mobile_Number"));
        driver.findElement(By.xpath("//div[@id='Email']//input")).sendKeys(prob.getProperty("email"));
        driver.findElement(By.xpath("//input[@id='pincode_gst_info']")).clear();
        driver.findElement(By.xpath("//input[@id='pincode_gst_info']")).sendKeys(prob.getProperty("pincode"));
        //driver.findElement(By.xpath("//input[@value='Maharashtra']")).click();
        //driver.findElement(By.xpath("//ul[@class='dropdownListWpr']//li[text()='Madhya Pradesh']")).click();
        driver.findElement(By.xpath("//span[@class='checkboxWpr']//b")).click();
        driver.findElement(By.xpath("//button[text()='Continue']")).click();

    }

















    public void close() // This method is used to close the browser
    {
        //driver.quit();
    }
}
