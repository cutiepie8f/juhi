package testpackage;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static testpackage.AutomationClass.prob;

public class TestClass {

    AutomationClass a = new AutomationClass();

    @Before
    public void setup() throws IOException {
        a.browserInvocation();
    }

     @Test
     public void test() throws InterruptedException {
          a.selectDepartureCity(prob.getProperty("departureCity"));
          Assert.assertTrue(a.validateDepartureCity());
          a.selectArrivalCity(prob.getProperty("arrivalCity"));
          Assert.assertTrue(a.validateArrivalCity());
          Assert.assertTrue(a.calenderIsEnabled());
          a.dateDropdown(prob.getProperty("date"));
          Assert.assertTrue(a.validateDateDropdown());
          a.selectTravellers(prob.getProperty("adultTravellers"));
          Assert.assertTrue( a.validateTravellers());
          a.selectFareType();
          //Assert.assertTrue(a.validateFareType());
          a.clickOnSearchButton();
          String expectedText = "Flights from Mumbai to Bengaluru";
         Assert.assertEquals(expectedText,a.validateFlightSelectingPage());
         a.selectFlight();
         expectedText = "Complete your booking";
         Assert.assertEquals(expectedText,a.validateFlighytBookingPage());
         a.selectInformationCheckbox();
         Assert.assertTrue(a.validateInformationCheckboxIsSelected());
         a.selectTripSecureRadioButton();
         Assert.assertTrue(a.validateTripSecureRadioButton());
         a.addTravellersDetails();
     }


     @After
    public void tearDown()
    {
        a.close();
    }

}
