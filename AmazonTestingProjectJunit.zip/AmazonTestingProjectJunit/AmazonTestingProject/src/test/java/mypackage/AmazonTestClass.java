package mypackage;

import java.time.Duration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonTestClass {
	
	
	AmazonClass amazon = new AmazonClass();
	
	@Before
	public void setup()
	{
		amazon.browserInvocation();
	}

	@Test
	public void checkAmazonFunctinalities()  // This is the testcase to check amazon functionalities like search product, sort the product, select the product,add-to-cart the product and proceed-to-checkout the product
	{
		
		amazon.searchTheProduct();
		amazon.sortTheProduct();
		amazon.selectTheProduct(1);
		amazon.clickOnAddToCartButton();
		amazon.clickOnProceedToCheckoutButton();
	}
	
	@After
	public void teardown()
	{
		amazon.close();
	}
}
