package mypackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.InvalidArgumentException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AmazonClass  {

		public WebDriver driver;
		public Select select;
		
		public void browserInvocation()
		{
			driver = new ChromeDriver();
			driver.get("https://www.amazon.in/");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}
		
		public void searchTheProduct()      // This method used to search the product "iphone"
		{
			driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("iphone");
			driver.findElement(By.id("nav-search-submit-button")).click();
			
		}
		
		public void sortTheProduct() // This method used to sort the searched product "iphone" High-to-low
		{
			WebElement sortBy = driver.findElement(By.xpath("//select[@id='s-result-sort-select']"));
	        select = new Select(sortBy);
	        select.selectByValue("price-desc-rank");
	        
		}
		public void selectTheProduct(int index)  // This method used to select the one particular product from the searched product "iphone"
		{
			driver.findElement(By.xpath("//div[@data-component-type='s-search-result']["+index+"]//div[2]//a")).click();
			Set<String> windowHandles = driver.getWindowHandles();
			Iterator<String> iterator = windowHandles.iterator();
			String parent = iterator.next();
			String child = iterator.next();
			driver.switchTo().window(child);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,250)", "");
			
		}
		public void clickOnAddToCartButton()    // This method used to add-to-cart the product "iphone"
		{
			driver.findElement(By.xpath("//input[@value='Add to Cart']")).click();
			
		}
		public void clickOnProceedToCheckoutButton()    // This method used to click on Proceed-to-cart the product "iphone"
		{
			driver.findElement(By.id("attach-sidesheet-checkout-button")).click();
			
		}
		
		public void close()
		{
			driver.quit();
		}
		

	
}

