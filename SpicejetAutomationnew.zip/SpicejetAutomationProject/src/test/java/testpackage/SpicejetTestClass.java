package testpackage;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;

public class SpicejetTestClass {

    SpicejetClass s = new SpicejetClass();

@BeforeMethod
    public void setup() throws IOException {
    s.browserInvocation();
}

@Test
public void test() throws InterruptedException {
    s.selectDepartureCity();
    s.selectArrivalCity(" Coimbatore (CJB)");
    s.dateDropdown("24");
    s.PassengerDropdown("4");
    s.currencyDropdown("INR");
    s.radioButton();
    s.checkBox();
    s.clickSearchButton();
    String expectedTitle = "Cheap Air Tickets Online, International Flights to India, Cheap International Flight Deals | SpiceJet Airlines";
    Assert.assertEquals(expectedTitle,s.validateBookingPageTitle());
}

@AfterMethod
    public void tearDown()
{
    s.close();
}

}
