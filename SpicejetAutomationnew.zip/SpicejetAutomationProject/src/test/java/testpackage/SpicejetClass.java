package testpackage;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

public class SpicejetClass {

    public  static WebDriver driver;
    public  static Properties prob;
    public void browserInvocation() throws IOException {
        driver = new ChromeDriver();
        FileInputStream fis = new FileInputStream(new File("src/main/resources/configuration/config.properties"));
        prob = new Properties();
        prob.load(fis);
        driver.navigate().to(prob.getProperty("url"));
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    }

   public void selectDepartureCity()
   {
       driver.findElement(By.id("ControlGroupSearchView_AvailabilitySearchInputSearchVieworiginStation1_CTXT")).click();
       driver.findElement(By.xpath("//a[@value='PNQ']")).click();
   }

   public void selectArrivalCity(String city)
   {
       driver.findElement(By.xpath("//a[text()='" + city + "']")).click();
   }

    public void dateDropdown(String date)
    {
        //driver.findElement(By.xpath("//button[@class='ui-datepicker-trigger']")).click();
        while(!driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText().equals("January"))
        {
            driver.findElement(By.xpath("//span[text()='Next']")).click();
        }
        WebElement element = driver.findElement(By.xpath("//input[@id='custom_date_picker_id_1']"));
        element.findElement(By.xpath("//a[text()='"+date+"']")).click();
    }


    public void PassengerDropdown(String value) throws InterruptedException {

        driver.findElement(By.xpath("//div[@class='book']")).click();
        driver.findElement(By.id("divpaxinfo")).click();
        WebElement element = driver.findElement(By.id("ControlGroupSearchView_AvailabilitySearchInputSearchView_DropDownListPassengerType_ADT"));
        Select adult = new Select(element);
        adult.selectByValue(value);
    }

    public void currencyDropdown(String value) throws InterruptedException {
        Thread.sleep(2000);
        WebElement element = driver.findElement(By.id("ControlGroupSearchView_AvailabilitySearchInputSearchView_DropDownListCurrency"));
        Select currency = new Select(element);
        currency.selectByValue(value);
    }

    public void radioButton() throws InterruptedException {
        driver.findElement(By.id("ControlGroupSearchView_AvailabilitySearchInputSearchView_RoundTrip")).click();
    }

    public void checkBox() throws InterruptedException {
        driver.findElement(By.id("ControlGroupSearchView_AvailabilitySearchInputSearchView_SeniorCitizen")).click();
    }

    public void clickSearchButton()
    {
        driver.findElement(By.xpath("//input[@type='submit']")).click();

    }

    public String  validateBookingPageTitle()
    {
        String actualTitle = driver.getTitle();
        return actualTitle;

    }
    public void close()
   {
       driver.quit();
   }
}
