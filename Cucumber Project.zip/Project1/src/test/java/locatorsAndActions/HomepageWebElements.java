package locatorsAndActions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utils.BaseWebDriver;
import Utils.Commonmethods;


public class HomepageWebElements {
	
	BaseWebDriver baseWebDriver=new BaseWebDriver();
	WebDriver driver=baseWebDriver.driver();
	Commonmethods commonMethod= new Commonmethods(driver);
	
	
	By searchtextbox = By.xpath("//input[@type='search']");
	By searchbutton = By.xpath("//button[@class='search-button']");
	By addtocartbutton = By.xpath("//div[@class='product']/div[3]/button");
	By basketbutton = By.xpath("//a[@class='cart-icon']");
	By proceedtocheckoutbutton = By.xpath("//div[@class='cart-preview active']/div[2]/button");
	By placeorderbutton = By.xpath("//div[@class='products']/div/button");
	By selectcountrydropdown = By.xpath("//div[@class='products']/div/div/select");
	By termsandconditionscheckbox = By.xpath("//input[@type='checkbox']");
	By proceedbutton = By.xpath("//button[text()='Proceed']");
	By orderplacedtext = By.linkText("Home");
	
	
	
	public void openMainPage(){
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
	}
	
	public void onClickOfSearchTextbox(String item) {
		 commonMethod.explicitWait(searchtextbox);
		 driver.findElement(searchtextbox).sendKeys(item);		
	}
	
	public void onClickOfSearchButton() {
		commonMethod.explicitWait(searchbutton);
		driver.findElement(searchbutton).click();
	}
	
	public void onClickOfAddToCartButton() {
		commonMethod.explicitWait(addtocartbutton);
		driver.findElement(addtocartbutton).click();
	}
	
	public void onClickOfBasketButton() {
		commonMethod.explicitWait(basketbutton);
		driver.findElement(basketbutton).click();
	}
	
	public void onClickOfProceedToCheckoutButton() {
		commonMethod.explicitWait(proceedtocheckoutbutton);
		driver.findElement(proceedtocheckoutbutton).click();	
	}

	public void onClickOfPlaceOrderButton() throws InterruptedException {
		commonMethod.explicitWait(placeorderbutton);
		driver.findElement(placeorderbutton).click();
	} 
	
	public void selectingcountrydropdown(String string) {
		
		commonMethod.explicitWait(selectcountrydropdown);
		Select countryDropdown=new Select(driver.findElement(selectcountrydropdown));
		countryDropdown.selectByVisibleText(string);
		}
	
	public void onClickofTermsAndConditionsCheckbox() {
		commonMethod.explicitWait(termsandconditionscheckbox);
		driver.findElement(termsandconditionscheckbox).click();
	}
	
	public void onClickofproceedbutton() {
		commonMethod.explicitWait(proceedbutton);
		driver.findElement(proceedbutton).click();	
	}
	
	public String gettextafterplacingorder(){
		commonMethod.explicitWait(orderplacedtext);
		return driver.findElement(orderplacedtext).getText();
	}
	
}
