package stepdefinitions;

import static org.junit.Assert.assertTrue;

import io.cucumber.java.en.*;
import locatorsAndActions.HomepageWebElements;

public class stepdefinition {
	
	HomepageWebElements actionsOnWebElements=new HomepageWebElements();
	
	@Given("User is in Home page")
	public void user_is_in_Home_page() {
		actionsOnWebElements.openMainPage();
	}
	 @When("User searches the item {string} in the search box")
		public void user_searches_the_item_in_the_search_box(String string) throws InterruptedException {
		 actionsOnWebElements.onClickOfSearchTextbox(string);
		}

	 @And("User clicks on Add to cart button")
		public void user_clicks_on_Add_to_cart_button() throws InterruptedException {
		 actionsOnWebElements.onClickOfAddToCartButton();
		} 
	 @And("User click on the cart icon")
		public void user_click_on_the_cart_icon() throws InterruptedException {
		 actionsOnWebElements.onClickOfBasketButton();
		}  
	
	 @And("User clicks on proceed to checkout box")
	 public void user_clicks_on_proceed_to_checkout_box() throws InterruptedException {
		 actionsOnWebElements.onClickOfProceedToCheckoutButton();
	  
	 }
	 @And("User clicks on place order")
	 public void user_clicks_on_place_order() throws InterruptedException {
		 actionsOnWebElements.onClickOfPlaceOrderButton();
	     
	 }
	 @And("User selects the country {string} from dropdown")
	 public void user_selects_the_country_from_dropdown(String string) {
		 actionsOnWebElements.selectingcountrydropdown(string);
	     
	 }
	 @And("User clicks on terms and contitions checkbox")
	 public void clicks_on_terms_and_contitions_checkbox() throws InterruptedException {
		 actionsOnWebElements.onClickofTermsAndConditionsCheckbox();
	 }
	 @And("User clicks proceed button")
	 public void user_clicks_proceed_button() throws InterruptedException {
		 actionsOnWebElements.onClickofproceedbutton();
	 }
	 @Then("Validate the order placed is successful")
	 public void validate_the_order_placed_is_successful_or_unsuccessful() {
		 String expectedText="Home";
		 String actualText=actionsOnWebElements.gettextafterplacingorder();
		 assertTrue(expectedText.equals(actualText));	
	 }
}
