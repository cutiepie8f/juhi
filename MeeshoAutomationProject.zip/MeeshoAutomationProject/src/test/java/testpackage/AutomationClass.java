package testpackage;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.Key;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class AutomationClass {
    public static WebDriver driver;
    public static Properties prob;

    public void browserInvocation() throws IOException  // This method is used to invoke the browser
    {
        driver = new ChromeDriver();
        FileInputStream fis = new FileInputStream(new File("src/main/resources/configuration/config.properties"));
        prob = new Properties();
        prob.load(fis);
        driver.navigate().to(prob.getProperty("url"));
        driver.manage().window().maximize();

    }

    public void search() {

        driver.findElement(By.xpath("//section[@class='header-nav-wrapper']//a[@id='nav_link_2']")).click();

    }

    public void select() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,420)", "");
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(80));
        w.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='ais-InfiniteHits']//li[7]//div[@class='plp-card-details-name line-clamp jm-body-xs jm-fc-primary-grey-80']")));
        driver.findElement(By.xpath("//div[@class='ais-InfiniteHits']//li[7]//div[@class='plp-card-details-name line-clamp jm-body-xs jm-fc-primary-grey-80']")).click();

    }

    public void addtocart() {
        driver.findElement(By.xpath("//button[@class='jm-btn primary medium center full-width jm-fw-bold addtocartbtn']")).click();
        driver.findElement(By.xpath("//section[@class='header-main']//button[@id='btn_minicart']")).click();
    }

    public void gotocart() {

        //driver.findElement(By.xpath("//button[@name='placeorder'][1]")).click();
        WebDriverWait we = new WebDriverWait(driver, Duration.ofSeconds(80));
        we.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='place-order smartcolor']//button[@class='j-button j-button-size__medium j-button-state__normal primary has-title j-button-flex ng-star-inserted']")));
        driver.findElement(By.xpath("//div[@class='place-order smartcolor']//button[@class='j-button j-button-size__medium j-button-state__normal primary has-title j-button-flex ng-star-inserted']")).click();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); // 30 seconds implicit wait


    }

    public void mobilenumber() throws InterruptedException {

        driver.findElement(By.xpath("//input[@placeholder='Enter your mobile number']")).sendKeys(prob.getProperty("mobile_number") + Keys.ENTER);

    }

    //public void enterno() {
        //ArrayList<String> list = new ArrayList<String>(driver.getWindowHandles());
        //driver.switchTo().window(list.get(1));

       // WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(80));
       // w.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Enter your mobile number']")));

        //driver.findElement(By.xpath("//input[@placeholder='Enter your mobile number']")).click();
   // }
    public void close() {

        driver.quit();
    }

}