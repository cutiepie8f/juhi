package testpackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

public class TestClass {

    AutomationClass a = new AutomationClass();

    @Before
    public void setup() throws IOException {
        a.browserInvocation();
    }

    @Test
    public void AutomationPge() throws InterruptedException {
       a.search();
     a.select();
     a.addtocart();
     a.gotocart();
    a.mobilenumber();
   // a.enterno();

    }
    @After
    public void tearDown(){
        a.close();
    }

}
