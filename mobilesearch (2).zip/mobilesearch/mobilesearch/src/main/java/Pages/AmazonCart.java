package Pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;

import Base.Base;

public class AmazonCart extends Base{
	String email="khatkejuhi09@gmail.com";
	String Password="appy@44";

        public void OpenUrl(){
        	
        	
		
		  driver.get("https://www.amazon.in/");
	    }
	
	    //To search for the details
	    public  void search() throws IOException, InterruptedException{
		
		String title=driver.getTitle();
		if(title.contains("Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in")) {
			System.out.println("Amazon Page loaded and verified");
		}
		else {
			System.out.println("Page not verified");
		}
	
		
		
		
		
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(prop.getProperty("place"));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(3000);
		String search=driver.findElement(By.xpath("//*[@id='search']/span/div/h1/div/div[1]/div/div/span[1]")).getText();
		System.out.println("Search Result: "+search+" this search result");
		System.out.println("");
		System.out.println("");
		System.out.println("");
		
		Thread.sleep(3000);
		Select drpCountry = new Select(driver.findElement(By.id("s-result-sort-select")));
		drpCountry.selectByVisibleText("Price: High to Low");
		Thread.sleep(3000);
	     Thread.sleep(3000);
	     driver.findElement(By.xpath("(//div[@id='p_36-title']/following::ul/li)[4]")).click();
	     Thread.sleep(3000);
		
		
		Thread.sleep(3000);
		 WebElement l=driver.findElement(By.xpath("(//div[@class='colorsprite aok-float-left'])[3]"));
	      // Actions class with moveToElement()
	      Actions a = new Actions(driver);
	      a.moveToElement(l).click().perform();
	      
	      Thread.sleep(5000);
	      TakesScreenshot capture = (TakesScreenshot) driver;
			File srcFile = capture.getScreenshotAs(OutputType.FILE);
			File destFile = new File(System.getProperty("user.dir")
					+ "/Screenshot/" + "Results.png");
			Files.copy(srcFile, destFile);
	      
	      System.out.println("*********:- List of Mobiles from filterrd Output :- ************");
	      List<WebElement> s1=driver.findElements(By.xpath("//span[@class='a-size-medium a-color-base a-text-normal']"));
	      for(int i=0;i<10;i++)
	      {
	    	  System.out.println("*******************");
	    	  System.out.println(i);
	    	  System.out.println(s1.get(i).getText());
	    	  System.out.println("*******************");
	    	  System.out.println("");
	    	  
	      }
	      
	      Thread.sleep(3000);
	      driver.findElement(By.xpath("(//span[@class='a-size-medium a-color-base a-text-normal'])[1]")).click();
	      Set<String> windowhandles=driver.getWindowHandles();
	      Iterator<String> iterator=windowhandles.iterator();
	      String parent=iterator.next();
	      String child=iterator.next();
	      driver.switchTo().window(child);
	      
	      Thread.sleep(3000);
	      JavascriptExecutor js = (JavascriptExecutor) driver;
	      js.executeScript("window.scrollBy(0,250)", "");
	      driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
	      
	      Thread.sleep(8000);
	 driver.findElement(By.xpath("//span[@id='attach-sidesheet-checkout-button']")).click();
	 Thread.sleep(5000);
	 driver.findElement(By.xpath("//input[@id='ap_email']")).clear();
	 Thread.sleep(2000);
	 
	 driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(email);
	 Thread.sleep(2000);
	 
	 driver.findElement(By.xpath("//input[@id='continue']")).click();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//input[@id='ap_password']")).clear();
	 Thread.sleep(2000);
	 
	 driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys(Password);
	 Thread.sleep(2000);
	 
	 driver.findElement(By.id("signInSubmit")).click();
	 Thread.sleep(7000);
	 driver.findElement(By.xpath("//a[@id='add-new-address-popover-link']")).click();
	 Thread.sleep(3000);
	 
	 driver.findElement(By.xpath("//input[@aria-label='Full name']")).sendKeys("Juhi");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//input[@aria-label='Mobile number']")).sendKeys("8839361380");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//input[@aria-label='Pincode']")).sendKeys("462039");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//input[@aria-label='Flat, House no., Building, Company, Apartment']")).sendKeys("Sector C , Shahpura");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//input[@aria-label='Area, Street, Sector, Village']")).sendKeys("Sector C Bhopal");
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//input[@aria-label='Town/City']")).clear();
	 Thread.sleep(3000);
	 driver.findElement(By.xpath("//input[@aria-label='Town/City']")).sendKeys("Bhopal");
	 Thread.sleep(3000);
	
	 
	 Select Country = new Select(driver.findElement(By.id("address-ui-widgets-enterAddressStateOrRegion-dropdown-nativeId")));
		Country.selectByVisibleText("MADHYA PRADESH");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//span[@id='address-ui-widgets-form-submit-button']")).click();
		
		Thread.sleep(10000);
		  TakesScreenshot captures = (TakesScreenshot) driver;
					File srcFiles = captures.getScreenshotAs(OutputType.FILE);
					File destFiles = new File(System.getProperty("user.dir")
							+ "/Screenshot/" + "CheckoutPage.png");
					Files.copy(srcFiles, destFiles);
	 Thread.sleep(6000);
	
	 System.out.println("******** -:AllPayment Methods are :- ****************");
	 System.out.println("");
	 System.out.println( driver.findElement(By.xpath("(//div[@class='a-box-inner'])[1]")).getText());
	 System.out.println("");
	 
	    }
	   
	    
	
	public static void main(String[] args) throws InterruptedException, IOException{
		AmazonCart ha= new AmazonCart();
		ha.driverSetup();
		ha.OpenUrl();
		ha.search();
		ha.closeBrowser();
	}
}
