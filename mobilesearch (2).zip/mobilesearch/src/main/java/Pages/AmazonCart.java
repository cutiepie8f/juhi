package Pages;

import static org.testng.AssertJUnit.assertEquals;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.hc.core5.util.Asserts;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonCart {

	public WebDriver driver;
 @BeforeMethod
	public void OpenUrl() {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);

		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		

	}
   @Test
	// To search for the details
	public void search() throws IOException, InterruptedException {
		String title = driver.getTitle();
		String expectedTitle = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";

		Assert.assertEquals(expectedTitle, title);
	
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("Mobile Phones");
		
		driver.findElement(By.xpath("//input[@type='submit']")).click();
	
		String search = driver.findElement(By.xpath("//*[@id='search']/span/div/h1/div/div[1]/div/div/span[1]")).getText();
		Select drpCountry = new Select(driver.findElement(By.id("s-result-sort-select")));
		drpCountry.selectByVisibleText("Price: High to Low");
		
		 WebElement element = driver.findElement(By.cssSelector("a.a-link-normal.s-underline-text.s-underline-link-text.s-link-style.a-text-normal"));
		 element.click();


		WebElement l = driver.findElement(By.xpath("(//div[@class='colorsprite aok-float-left'])[3]"));
		

		Actions a = new Actions(driver);
		a.moveToElement(l).click().perform();
		driver.findElement(By.xpath("(//span[@class='a-size-medium a-color-base a-text-normal'])[1]")).click();
		Set<String> windowhandles = driver.getWindowHandles();
		Iterator<String> iterator = windowhandles.iterator();
		String parent = iterator.next();
		String child = iterator.next();
		driver.switchTo().window(child);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();

		driver.findElement(By.xpath("//span[@id='attach-sidesheet-checkout-button']")).click();

		driver.findElement(By.xpath("//input[@id='ap_email']")).clear();

		String email = "khatkejuhi09@gmail.com";
		String Password = "chinu11";
		
	
	
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(email);

		driver.findElement(By.xpath("//input[@id='continue']")).click();

		driver.findElement(By.xpath("//input[@id='ap_password']")).clear();

		driver.findElement(By.xpath("//input[@id='ap_password']")).sendKeys(Password);

		driver.findElement(By.id("signInSubmit")).click();
		
        element = driver.findElement(By.cssSelector("a#add-new-address-popover-link.a-size-base.a-link-normal"));
        element.click();

        
		

		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressFullName']")).sendKeys("Juhi");
		
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPhoneNumber']")).sendKeys("8839361380");

		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPostalCode']")).clear();
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPostalCode']")).sendKeys("462039");

		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine1']")).sendKeys(" Sector C, Bhopal");

		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine2']")).sendKeys("Sector C Bhopal");

		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressCity']")).clear();

		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressCity']")).sendKeys("Bhopal");

		Select Country = new Select(driver.findElement(By.id("address-ui-widgets-enterAddressStateOrRegion-dropdown-nativeId")));
		Country.selectByVisibleText("MADHYA PRADESH");
		
		driver.findElement(By.xpath("//span[@id='address-ui-widgets-form-submit-button']")).click();
		driver.quit();
	}

	public static void main(String[] args) throws InterruptedException, IOException {
		AmazonCart ha = new AmazonCart();

		ha.OpenUrl();
		ha.search();

	}
}
