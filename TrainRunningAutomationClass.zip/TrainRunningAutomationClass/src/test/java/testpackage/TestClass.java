package testpackage;

import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

import static testpackage.TrainAutomationClass.prob;

public class TestClass {
    TrainAutomationClass t = new TrainAutomationClass();

    @Before
    public void setup() throws IOException {
        t.browserInvocation();
    }

    @Test
    public void TrainRunningStatus() throws InterruptedException {
        t.searchtrainnumber();
        t.checkStatus();
        t.searchstationname();
        t.fromselectstationname();
        t.toselectstationname();
        t.selectdate();
        t.search();


    }
}
