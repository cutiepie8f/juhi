package testpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.Key;
import java.time.Duration;
import java.util.Properties;

public class TrainAutomationClass {

    public static WebDriver driver;
    public static Properties prob;

    public void browserInvocation() throws IOException  // This method is used to invoke the browser
    {
        driver = new ChromeDriver();
        FileInputStream fis = new FileInputStream(new File("src/main/resources/configuration/config.properties"));
        prob = new Properties();
        prob.load(fis);
        driver.navigate().to(prob.getProperty("url"));
        driver.manage().window().maximize();
    }

    public void searchtrainnumber() {
        //driver.findElement(By.xpath("//header[@class='happy-gi-header gi-special-theme-left header-sticky']//li[3]//p[@class='sc-gEvEer BkcDM']")).click();
        //driver.findElement(By.cssSelector("styles_FswTripTypeItemRadio__Zy5tX styles_FswTripTypeItemRadioSelected__OfKHq")).click();
        //driver.findElement(By.cssSelector("styles_FswTripTypeItem__aPaXl styles_FswTripTypeItemSelected__5SNch")).click();
        driver.findElement(By.xpath("//p[text()='Enter Train number or name']")).click();

        //driver.findElement(By.cssSelector("styles_FswFld__UzC_6 styles_fswFld__u5UWc")).click();

        driver.findElement(By.xpath("//ul[@class='styles_FswAutoCompBody__tuU_O']//li[@class='styles_FswAutoCompItem__RE1dP'][4]")).click();
    }

    public void checkStatus() {
        driver.findElement(By.xpath("//span[text()='CHECK STATUS']")).click();

        WebDriverWait we = new WebDriverWait(driver, Duration.ofSeconds(80));
        we.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search station']")));
        driver.findElement(By.xpath("//input[@placeholder='Search station']")).click();
    }

    public void searchstationname() {
        driver.findElement(By.xpath("//ul[@class='srchbx__options']//li[4]//span[@class='srchbx__stnName']")).click();
        //driver.findElement(By.xpath("//div[@class='trnTmTbl']//div[4]//p[@class='trnCard__content--name']")).click();
        driver.findElement(By.xpath("//a[@href='https://www.goibibo.com/trains/ratlam-junction-rtm-stn/']")).click();
    }

    public void fromselectstationname() {
        driver.findElement(By.xpath("//div[@class='autoSuggest']//input[@class='form-control inputTxtLarge widgetInputWrap fb quicks'][1]")).sendKeys(prob.getProperty("FromStation_name"));
        //driver.findElement(By.xpath("//div[@class='autoSuggest']//input[@class='form-control inputTxtLarge widgetInputWrap fb quicks'][1]")).click();
        //driver.findElement(By.xpath("//div[@class='autoSuggest']//input[@type='text'][1]")).sendKeys(prob.getProperty("Station_name"));
    }

    public void toselectstationname() {
        driver.findElement(By.xpath("//div[@class='col-md-7 col-xs-12']//div[2]//input")).sendKeys(prob.getProperty("ToStation_name"));


    }

    public void selectdate()  {
        driver.findElement(By.id("seoStationcal")).click();
        //driver.findElement(By.xpath("//div[@class='DayPicker']//div[@class='DayPicker-Day '][3]")).click();
        driver.findElement(By.xpath("//span[@aria-label='Next Month']")).click();
        driver.findElement(By.xpath("//div[@class='DayPicker']//div[3]//div[text()='24']")).click();

    }

    public void search()  {
        //driver.findElement(By.id("gi_search_btn")).click();
        // driver.findElement(By.cssSelector("//input[@value='SEARCH']")).click();
        //driver.findElement(By.cssSelector("col-md-12 col-sm-12 col-xs-12 goCamp padT2 txtCenter posRel")).click();
        driver.findElement(By.xpath("//div[@class='width100 homeWidgetWrap posRel fl']//div[4]//input[@id='gi_search_btn']")).click();
    }

}