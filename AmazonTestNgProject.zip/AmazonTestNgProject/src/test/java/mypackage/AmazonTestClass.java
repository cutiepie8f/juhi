package mypackage;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AmazonTestClass {
	
	
	AmazonClass amazon = new AmazonClass();
	
	@BeforeMethod
	public void setup()
	{
		amazon.browserInvocation();
	}

	@Test
	public void checkAmazonFunctinalities()  // This is the testcase to check amazon functionalities like search product, sort the product, select the product,add-to-cart the product and proceed-to-checkout the product
	{
		
		amazon.searchTheProduct();
		amazon.sortTheProduct();
		amazon.selectTheProduct(7);
		amazon.clickOnAddToCartButton();
		amazon.clickOnProceedToCheckoutButton();
		amazon.signin();
		amazon.addNewAddres();
	}
	
	@AfterMethod
	public void teardown()
	{
		amazon.close();
	}
}
