package mypackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.InvalidArgumentException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AmazonClass  {

		public WebDriver driver;
		public Select select;
		
		public void browserInvocation()
		{
			driver = new ChromeDriver();
			driver.get("https://www.amazon.in/");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}
		
		public void searchTheProduct()      // This method used to search the product "iphone"
		{
			driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("iphone");
			driver.findElement(By.id("nav-search-submit-button")).click();
			
		}
		
		public void sortTheProduct() // This method used to sort the searched product "iphone" High-to-low
		{
			//WebElement sortBy = driver.findElement(By.xpath("//select[@id='s-result-sort-select']"));
			WebElement sortBy = driver.findElement(By.xpath("//span[@id='productTitle']"));
	        select = new Select(sortBy);
	        select.selectByValue("price-desc-rank");
	       
	        
		}
		public void selectTheProduct(int index)  // This method used to select the one particular product from the searched product "iphone"
		{
			driver.findElement(By.xpath("//div[@data-component-type='s-search-result']["+index+"]//div[2]//a")).click();
			Set<String> windowHandles = driver.getWindowHandles();
			Iterator<String> iterator = windowHandles.iterator();
			String parent = iterator.next();
			String child = iterator.next();
			driver.switchTo().window(child);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,250)", "");
			
		}
		public void clickOnAddToCartButton()    // This method used to add-to-cart the product "iphone"
		{
			driver.findElement(By.xpath("//input[@value='Add to Cart']")).click();
			
		}
		public void clickOnProceedToCheckoutButton()    // This method used to click on Proceed-to-cart the product "iphone"
		{
			driver.findElement(By.id("attach-sidesheet-checkout-button")).click();
			
		}
		
		public void signin()
		{
			driver.findElement(By.xpath("//input[@id='ap_email']")).clear();
			driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys("khatkejuhi09@gmail.com");
			driver.findElement(By.xpath("//input[@type='submit']")).click();
			driver.findElement(By.xpath("//input[@type='password']")).sendKeys("chinu11");
			driver.findElement(By.id("signInSubmit")).click();
		
		}
		
		public void addNewAddres()
		{
			driver.findElement(By.id("add-new-address-popover-link")).click();
			WebElement addressElement = driver.findElement(By.xpath("//select[@name='address-ui-widgets-countryCode']"));
			Select select = new Select(addressElement);
			select.selectByValue("IN");
			
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressFullName']")).sendKeys("Juhi");
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPhoneNumber']")).sendKeys("1234987654");
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPostalCode']")).clear();
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPostalCode']")).sendKeys("462039");
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine1']")).sendKeys("C sector 697");
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine2']")).sendKeys("shahpura");
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-landmark']")).sendKeys("near Bansal Hospital");
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressCity']")).clear();
			driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressCity']")).sendKeys("Bhopal");
			
			WebElement stateElement = driver.findElement(By.xpath("//div[@class='a-section a-spacing-base adddress-ui-widgets-form-field-container']//select[@name='address-ui-widgets-enterAddressStateOrRegion']"));
			Select selectState = new Select(stateElement);
			selectState.selectByValue("MADHYA PRADESH");
			driver.findElement(By.xpath("//span[@id='address-ui-widgets-form-submit-button']//child::input")).click();
			
			WebDriverWait w = new WebDriverWait(driver,Duration.ofSeconds(60));
			w.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@id='address-ui-widgets-form-submit-button-announce']")));
		
		}
		
		public void close()
		{
			//driver.quit();
		}
		

	
}

