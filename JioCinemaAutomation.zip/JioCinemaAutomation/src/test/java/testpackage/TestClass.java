package testpackage;

import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

public class TestClass {

    AutomationClass a = new AutomationClass();

    @Before
    public void setup() throws IOException {
        a.browserInvocation();
    }

    @Test
    public void SportsPage() throws InterruptedException {
        a.sport();
        a.sportsname();
        a.next();
        a.click();
    }
}
