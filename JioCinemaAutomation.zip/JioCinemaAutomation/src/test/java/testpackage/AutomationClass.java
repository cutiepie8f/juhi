package testpackage;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Properties;

public class AutomationClass {
    public static WebDriver driver;
    public static Properties prob;

    public void browserInvocation() throws IOException  // This method is used to invoke the browser
    {
        driver = new ChromeDriver();
        FileInputStream fis = new FileInputStream(new File("src/main/resources/configuration/config.properties"));
        prob = new Properties();
        prob.load(fis);
        driver.navigate().to(prob.getProperty("url"));
        driver.manage().window().maximize();
    }

    public void sport() {
        driver.findElement(By.xpath("//div[@class='mui-style-1ba2a6b-webroot bg-black-40']//div[2]//span[text()='Sports']")).click();

    }

    public void sportsname(){
        driver.findElement(By.xpath("//div[@class='slick-slider mui-style-2wnex8-root mx-4 md:mx-12 max-sm:p-0 sm:max-md:p-2 sm:max-md:mx-6 md:max-lg:px-3 lg:px-4 subnav-chip-carousel slick-initialized']//div[4]//button[@type='button']")).click();



    }

    public void next() {
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(80));
        w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='infinite-scroll-component ']//i[@id='rail_jio_voot-common_3697154_0_editorial_351481362'][2]")));
        driver.findElement(By.xpath("//div[@class='infinite-scroll-component ']//i[@id='rail_jio_voot-common_3697154_0_editorial_351481362'][2]")).click();
        //driver.findElement(By.cssSelector("carousel-card card-transform-origin-left bg-position-left grow-card-full centerCard")).click();


    }

    public void click(){
        driver.findElement(By.xpath("//div[@id='rail_jio_voot-common_3697154_0_editorial_351481362']//div[@class='carousel-card card-transform-origin-left bg-position-left grow-card-full centerCard']")).click();

    }
}


