package amazonpackage;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.InvalidArgumentException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import dev.failsafe.internal.util.Assert;

public class AmazonClass {

	public static WebDriver driver;
	public Select select;
	public static Properties prob;
	public void browserInvocation() throws IOException
	{
		FileInputStream fis = new FileInputStream(new File("src/main/resources/utilitypackage/config.properties"));
		prob = new Properties();
		prob.load(fis);
		if(prob.getProperty("browser").equalsIgnoreCase("chrome"))
		{
			driver = new ChromeDriver();
		}
		else if(prob.getProperty("browser").equalsIgnoreCase("edge"))
		{
			driver = new EdgeDriver();
		}
		else if(prob.getProperty("browser").equalsIgnoreCase("safari"))
		{
			driver = new SafariDriver();
		}
		else
		{
			throw new InvalidArgumentException("Please enter the correct browser details..... ");
		}
		
		driver.get(prob.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}
	public void enterProduct(String product)
	{
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(product);
	}
	
	public void clickSearchIcon()
	{
		driver.findElement(By.id("nav-search-submit-button")).click();
	}
	
	public void clickSortByDropdown()
	{
		
		 WebElement sortBy = driver.findElement(By.id("s-result-sort-select"));
	        select = new Select(sortBy);

	}
	
	public void selectByValue(String value)
	{
		clickSortByDropdown();
		select.selectByValue(value);
	}
	
	
	public void clickIphone(int index) throws InterruptedException
	{
		driver.findElement(By.xpath("//div[@data-cel-widget='search_result_"+index+"']")).click();
		
	}
	
	public void clickAddToCart() throws InterruptedException
	{
		Set<String> windowHandles = driver.getWindowHandles();
		Iterator<String> iterator = windowHandles.iterator();
		String parent = iterator.next();
		String child = iterator.next();
		driver.switchTo().window(child);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,250)", "");
		driver.findElement(By.xpath("//input[@value='Add to Cart']")).click();
	}
	
	public void clickProceedToPay() throws InterruptedException
	{
		driver.findElement(By.id("attach-sidesheet-checkout-button")).click();
	}
	public void enterUserName()
	{
		driver.findElement(By.xpath("//input[@id='ap_email']")).clear();
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys(prob.getProperty("email"));
	
	}
	
	public void clickContinueButton()
	{
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	}
	
	public void enterPassword()
	{
		
	driver.findElement(By.xpath("//input[@type='password']")).sendKeys(prob.getProperty("password"));
	}
	
	public void clickSignInButton()
	{
		driver.findElement(By.id("signInSubmit")).click();
	}
	
	public void addNewAddress()
	{
		driver.findElement(By.id("add-new-address-popover-link")).click();
		WebElement addressElement = driver.findElement(By.xpath("//select[@name='address-ui-widgets-countryCode']"));
		Select select = new Select(addressElement);
		select.selectByValue("IN");
		
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressFullName']")).sendKeys("Juhi");
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPhoneNumber']")).sendKeys("1234987654");
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPostalCode']")).clear();
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressPostalCode']")).sendKeys("462039");
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine1']")).sendKeys("C sector 697");
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressLine2']")).sendKeys("shahpura");
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-landmark']")).sendKeys("near Bansal Hospital");
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressCity']")).clear();
		driver.findElement(By.xpath("//input[@id='address-ui-widgets-enterAddressCity']")).sendKeys("Bhopal");
		
		WebElement stateElement = driver.findElement(By.xpath("//div[@class='a-section a-spacing-base adddress-ui-widgets-form-field-container']//select[@name='address-ui-widgets-enterAddressStateOrRegion']"));
		Select selectState = new Select(stateElement);
		selectState.selectByValue("MADHYA PRADESH");
		driver.findElement(By.xpath("//span[@id='address-ui-widgets-form-submit-button']//child::input")).click();
		
	}
	
	public void selectPaymentMethodAndBank() throws InterruptedException 
	{
		WebDriverWait w = new WebDriverWait(driver,Duration.ofSeconds(20));
		w.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@id='address-ui-widgets-form-submit-button-announce']")));
        WebElement bankElement = driver.findElement(By.name("ppw-bankSelection_dropdown"));
		Select selectBank = new Select(bankElement);
		selectBank.selectByValue("UTI DIRECT");
		
	}
	public void clickUseThisPaymentMethod() throws InterruptedException
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,250)", "");
		driver.findElement(By.name("ppw-widgetEvent:SetPaymentPlanSelectContinueEvent")).click();
	}

}
