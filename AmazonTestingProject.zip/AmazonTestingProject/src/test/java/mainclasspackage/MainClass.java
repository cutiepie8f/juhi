package mainclasspackage;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;

import amazonpackage.AmazonClass;

public class MainClass extends AmazonClass{

	public static void main(String[] args) throws InterruptedException, IOException {
		
		AmazonClass amazon = new AmazonClass();
		amazon.browserInvocation();
		amazon.enterProduct("iphone");
		amazon.clickSearchIcon();
		amazon.selectByValue("price-desc-rank");
		amazon.clickIphone(3);
		amazon.clickAddToCart();
		amazon.clickProceedToPay();
		amazon.enterUserName();
		amazon.clickContinueButton();
		amazon.enterPassword();
		amazon.clickSignInButton();
		amazon.addNewAddress();
		amazon.selectPaymentMethodAndBank();
		amazon.clickUseThisPaymentMethod();
		

	}

}
