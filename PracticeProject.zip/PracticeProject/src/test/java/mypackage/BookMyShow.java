package mypackage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BookMyShow {
    public static void main(String[]args){
        WebDriver driver = new ChromeDriver();
        driver.get("https://in.bookmyshow.com/explore/home/pune");
        driver.findElement(By.cssSelector(" .bwc__sc-1nbn7v6-8.hbuyht")).click();
        driver.findElement(By.cssSelector(".bwc__sc-1iyhybo-6.ilhhay")).sendKeys("M.S. Dhoni: The Untold Story" +Keys.ENTER);
        //driver.findElement(By.cssSelector(".banner__EventHeading-sc-qswwm9-6.bzWuzb")).click();
        //driver.findElement(By.cssSelector(".bwc__sc-3t17w7-22.giTXCu")).click();
    }



}
