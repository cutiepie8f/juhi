package mypackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SalesForcePage {

        WebDriver driver;
        @Before
        public void setup(){
            driver = new ChromeDriver();
            driver.get("https://login.salesforce.com/?locale=in");
        }
        @Test
        public void test() {
            driver.findElement(By.name("username")).sendKeys("Kaira");
            driver.findElement(By.id("password")).sendKeys("5678");
            driver.findElement(By.id("Login")).click();
            driver.findElement(By.id("forgot_password_link")).click();
            driver.findElement(By.id("un")).sendKeys("kaira2");
            driver.findElement(By.name("cancel")).click();
        }
        @After
        public void teardown() {
            driver.quit();
        }

}

