package mypackage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class VegEase {
    public static void main(String[]args) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://vegease.in/search");
        driver.manage().window().maximize();
        driver.findElement(By.xpath("//div[@class='pseudo-item']")).click();
        driver.findElement(By.xpath("//div[@class='col padding-0']")).click();
        //driver.findElement(By.xpath("//div[@class='row row-cols-2 row-cols-md-6 row-cols-lg-6 row-cols-xl-6 pt-1']//div[@class='product-card'][1]")).click();
        //WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(60));
        //w.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@class='product-add']")));
        driver.findElement(By.xpath("//div[@class='row row-cols-2 row-cols-md-6 row-cols-lg-6 row-cols-xl-6 pt-1']//div[@class='col padding-0'][1]")).click();
    }
}
