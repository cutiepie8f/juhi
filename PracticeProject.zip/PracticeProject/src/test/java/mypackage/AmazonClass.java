package mypackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AmazonClass {
    WebDriver driver;
    @Before
    public void setup() {
        driver = new ChromeDriver();
        driver.get("https://www.amazon.in/");
        driver.manage().window().maximize();
    }
    @Test
    public void test()
    {
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iphones"+ Keys.ENTER);
        driver.findElement(By.id("a-autoid-0-announce")).click();
        WebElement element = driver.findElement(By.cssSelector(".a-native-dropdown.a-declarative"));
        Select s = new Select(element);
        s.selectByValue("price-desc-rank");
        driver.findElement(By.cssSelector(".a-size-medium.a-color-base.a-text-normal")).click();
        driver.findElement(By.xpath("//div[@id='search']//div[4]//span[@class='a-size-medium a-color-base a-text-normal']")).click();
    }

    @After
    public void teardown(){

        //driver.quit();
    }
}
