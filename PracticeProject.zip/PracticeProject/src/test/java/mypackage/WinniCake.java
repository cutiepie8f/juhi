package mypackage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;

public class WinniCake {
    public static void main(String[] args) {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.winni.in/cake");
        driver.manage().window().maximize();
        driver.findElement(By.xpath("//input[@id='search-input-in-desktop']")).sendKeys("cakes" + Keys.ENTER);
        driver.findElement(By.xpath("//nav[@class='header-secondary hide-on-med-and-down']//li[7]//a[@class='dropdown-trigger borderBottomForCategories']")).click();
        driver.findElement(By.xpath("//div[@class='white']//li[2]//div[@class='truncate']")).click();
        ArrayList<String> list = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(list.get(1));
        driver.findElement(By.xpath("//span[@for='attval_1.5 kg']")).click();
        driver.findElement(By.xpath("//span[@class='eggless']")).click();
        driver.findElement(By.xpath("//input[@id='msgOnCakeAtt']")).click();
        driver.findElement(By.xpath("//input[@id='msgOnCakeAtt']")).sendKeys("Happy Birthday");
        driver.findElement(By.id("addToCartButton")).click();
        //driver.findElement(By.id("Capa_1")).click();


    }
}