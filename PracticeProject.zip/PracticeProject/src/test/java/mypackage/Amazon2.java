package mypackage;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Amazon2 {
    public static void main(String[]args){
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.amazon.in/");
        driver.manage().window().maximize();
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iphones" + Keys.ENTER);
        driver.findElement(By.id("a-autoid-0")).click();
       WebElement element = driver.findElement(By.id("s-result-sort-select"));
        Select s = new Select(element);
        s.selectByValue("price-desc-rank");
        driver.findElement(By.xpath("//div[@id='search']//span[@class='a-size-medium a-color-base a-text-normal'][1")).click();


    }
}

