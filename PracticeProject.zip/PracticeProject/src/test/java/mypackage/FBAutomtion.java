package mypackage;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FBAutomtion {
    WebDriver driver;

    @Before
    public void setup() {
        driver = new ChromeDriver();
        driver.get("https://www.facebook.com/");
    }

    // driver.findElement(By.xpath("//input[@id='email']")).sendKeys("abcd@gmail.com");
    //driver.findElement(By.xpath("//input[@name='pass']")).sendKeys("1234");
    // driver.findElement(By.xpath("//button[@name='login']")).click();
    @Test
    public void test() {
        driver.findElement(By.cssSelector("._42ft._4jy0._6lti._4jy6._4jy2.selected._51sy")).click();

//        driver.manage().window().maximize();
        driver.findElement(By.name("lastname")).sendKeys("Juhi");
    }
        @After
        public void teardown () {
            driver.close();
        }
    }
