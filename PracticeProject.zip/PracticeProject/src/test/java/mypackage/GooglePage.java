package mypackage;

import org.checkerframework.checker.units.qual.K;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.sql.Driver;

public class GooglePage {
    public static void main(String[]args){
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();
        driver.findElement(By.id("APjFqb")).sendKeys("Flowers" + Keys.ENTER);
        driver.findElement(By.id("rcnt")).click();
        driver.findElement(By.id("header-search-input")).sendKeys("Christmas Tree" + Keys.ENTER);
        driver.findElement(By.xpath("//div[@class='cdp']//div[@class='product-card_product-title__32LFp'][1]")).click();
        driver.findElement(By.cssSelector("MuiButtonBase-root MuiButton-root MuiButton-contained cart-buttons_formButtonGreen__2aFHS")).click();

    }
}
