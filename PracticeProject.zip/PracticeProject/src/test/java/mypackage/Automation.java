package mypackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Automation {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.facebook.com/");
        // driver.findElement(By.xpath("//input[@id='email']")).sendKeys("abcd@gmail.com");
        //driver.findElement(By.xpath("//input[@name='pass']")).sendKeys("1234");
        // driver.findElement(By.xpath("//button[@name='login']")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("._42ft._4jy0._6lti._4jy6._4jy2.selected._51sy")).click();
        Thread.sleep(10000);
//        driver.manage().window().maximize();
        driver.findElement(By.name("lastname")).sendKeys("Juhi");
        Thread.sleep(2000);
       // driver.close();
    }

}
